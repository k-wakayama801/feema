package util;

public class MyFormat {
	public String moneyFormat(int price) {
		return Integer.toString(price) + "円";
	}
}
