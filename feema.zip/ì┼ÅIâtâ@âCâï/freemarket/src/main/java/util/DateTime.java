package util;

import java.time.LocalDateTime;

public class DateTime {
	public LocalDateTime Time() {
		LocalDateTime nowDate = LocalDateTime.now();
		return nowDate;
	}
}
